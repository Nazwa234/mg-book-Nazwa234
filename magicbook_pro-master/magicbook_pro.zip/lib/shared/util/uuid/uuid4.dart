import 'package:hyper_ui/core.dart';

String get uuid4 {
  return const Uuid().v4();
}
