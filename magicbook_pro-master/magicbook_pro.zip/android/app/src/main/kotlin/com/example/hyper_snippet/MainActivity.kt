package com.example.hyper_snippet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
