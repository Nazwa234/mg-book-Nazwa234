*Update Magicbook*
Dear member, Latihan magicbook sekarang hanya ada di 1 projek ini saja yaa.
Untuk scores-nya, saya reset lagi jadi 0.

Next update, selain technical test,
Saya juga mau update Magicbook-nya supaya ada kuis seputar pertanyaan2 teknis yang sering ditanyakan Ketika interview. 

Berikut panduan untuk mengerjakannya yaa!

---
1. Clone repo ini:
```
git clone https://github.com/denyocrworld/magicbook_pro
```
2. Ketikkan perintah ini di terminal:
```
dart pub get
```
3. Jalankan MagicbookPro di real device android atau windows desktop
4. Login dengan akun member
5. Buka file berikut dan kerjakan sesuai instruksi di dalamnya!
```
lib/module/__exercise/technical_test.dart
```